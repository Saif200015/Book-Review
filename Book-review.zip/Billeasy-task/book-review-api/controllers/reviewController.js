const Review = require('../models/Review');

const addReview = async (req, res) => {
  const { id: bookId } = req.params;
  const { rating, comment } = req.body;
  const userId = req.user._id;

  if (!rating || rating < 1 || rating > 5) {
    return res.status(400).json({ message: 'Rating must be between 1 and 5' });
  }

  const existingReview = await Review.findOne({ book: bookId, user: userId });
  if (existingReview) {
    return res.status(400).json({ message: 'You have already reviewed this book' });
  }

  const review = await Review.create({ user: userId, book: bookId, rating, comment });
  res.status(201).json(review);
};

const updateReview = async (req, res) => {
  const { id } = req.params;
  const { rating, comment } = req.body;
  const userId = req.user._id;

  const review = await Review.findById(id);
  if (!review) return res.status(404).json({ message: 'Review not found' });

  if (review.user.toString() !== userId.toString()) {
    return res.status(403).json({ message: 'Not authorized to update this review' });
  }

  if (rating) review.rating = rating;
  if (comment) review.comment = comment;

  await review.save();
  res.json(review);
};

const deleteReview = async (req, res) => {
  const { id } = req.params;
  const userId = req.user._id;

  const review = await Review.findById(id);
  if (!review) return res.status(404).json({ message: 'Review not found' });

  if (review.user.toString() !== userId.toString()) {
    return res.status(403).json({ message: 'Not authorized to delete this review' });
  }

  await review.remove();
  res.json({ message: 'Review removed' });
};

const searchReviews = async (req, res) => {
    const query = {};
  
    if (req.query.user) {
      query.user = req.query.user;
    }
  
    if (req.query.book) {
      query.book = req.query.book;
    }
  
    if (req.query.rating) {
      query.rating = Number(req.query.rating);
    }
  
    try {
      const reviews = await Review.find(query)
        .populate('user', 'username email')  
        .populate('book', 'title author');   
  
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  };
  

module.exports = { addReview, updateReview, deleteReview,searchReviews };
