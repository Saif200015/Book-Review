const Book = require('../models/Book');
const Review = require('../models/Review');
const paginate = require('../utils/paginate');

const addBook = async (req, res) => {
  const { title, author, genre, description } = req.body;

  if (!title || !author || !genre) {
    return res.status(400).json({ message: 'Title, author, and genre are required' });
  }

  const book = await Book.create({ title, author, genre, description });
  res.status(201).json(book);
};

const getBooks = async (req, res) => {
  const { page, limit, skip } = paginate(req);
  const { author, genre } = req.query;

  const query = {};
  if (author) query.author = new RegExp(author, 'i');
  if (genre) query.genre = new RegExp(genre, 'i');

  const total = await Book.countDocuments(query);
  const books = await Book.find(query).skip(skip).limit(limit);

  res.json({ total, page, limit, books });
};

const getBookById = async (req, res) => {
  const { id } = req.params;
  const { page, limit, skip } = paginate(req);

  const book = await Book.findById(id);
  if (!book) return res.status(404).json({ message: 'Book not found' });

  const reviews = await Review.find({ book: id })
    .populate('user', 'username')
    .skip(skip)
    .limit(limit)
    .sort({ createdAt: -1 });

  const totalReviews = await Review.countDocuments({ book: id });

  const agg = await Review.aggregate([
    { $match: { book: book._id } },
    { $group: { _id: '$book', avgRating: { $avg: '$rating' } } }
  ]);
  const avgRating = agg.length > 0 ? agg[0].avgRating : null;

  res.json({ book, avgRating, totalReviews, page, limit, reviews });
};

const searchBooks = async (req, res) => {
    const { q } = req.query;
    if (!q) return res.status(400).json({ message: 'Query parameter "q" is required' });
  
    const regex = new RegExp(q, 'i');
    const books = await Book.find({
      $or: [{ title: regex }, { author: regex }]
    });
  
    res.json(books);
  };
  

module.exports = { addBook, getBooks, getBookById ,searchBooks};

