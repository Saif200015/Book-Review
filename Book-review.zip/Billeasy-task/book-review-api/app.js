const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const { errorHandler } = require('./middlewares/errorMiddleware');

dotenv.config();
connectDB();

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.use('/api', require('./routes/authRoutes'));
app.use('/api', require('./routes/bookRoutes'));
app.use('/api', require('./routes/reviewRoutes'));

app.use(errorHandler);

module.exports = app;
