const express = require('express');
const { protect } = require('../middlewares/auth');
const { updateReview, deleteReview, searchReviews } = require('../controllers/reviewController');

const router = express.Router();

router.put('/reviews/:id', protect, updateReview);
router.delete('/reviews/:id', protect, deleteReview);

router.get('/reviews', searchReviews);

module.exports = router;
