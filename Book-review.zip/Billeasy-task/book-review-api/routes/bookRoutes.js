const express = require('express');
const { protect } = require('../middlewares/auth');
const { addBook, getBooks, getBookById, searchBooks } = require('../controllers/bookController');
const { addReview } = require('../controllers/reviewController');

const router = express.Router();

router.post('/books', protect, addBook);
router.get('/books', getBooks);
router.get('/books/:id', getBookById);
router.post('/books/:id/reviews', protect, addReview);
router.get('/search', searchBooks);


router.post('/books/:id/reviews', protect, addReview);

module.exports = router;
